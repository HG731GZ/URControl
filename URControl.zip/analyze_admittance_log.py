"""只读汇总导纳日志，供人工排查；不连接设备、不修改日志、不作通过或失败判定。"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import math
from pathlib import Path


def numeric_value(value):
    """识别日志声明的空值及非有限数值标记，不将缺测替换为零。"""
    if value is None:
        return None
    if isinstance(value, dict) and set(value) == {"non_finite_float"}:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"统计字段必须为数字、空值或已声明的非有限标记，实际为 {value!r}")
    return value if math.isfinite(value) else None


class NumericSummary:
    """逐条累计范围及最大值的位置，只保存常量大小的统计结果。"""

    def __init__(self):
        self.count = 0
        self.missing = 0
        self.minimum = None
        self.maximum = None
        self.maximum_location = None

    def add(self, value, location=None):
        value = numeric_value(value)
        if value is None:
            self.missing += 1
            return
        self.count += 1
        if self.minimum is None or value < self.minimum:
            self.minimum = value
        if self.maximum is None or value > self.maximum:
            self.maximum = value
            self.maximum_location = location

    def report(self, *, maximum_only=False):
        if not self.count:
            return {"状态": "未取得有限数值", "缺测或非有限数量": self.missing}
        result = {"有限数值数量": self.count, "缺测或非有限数量": self.missing,
                  "最大值": self.maximum}
        if not maximum_only:
            result["最小值"] = self.minimum
        if self.maximum_location is not None:
            result["最大值位置"] = self.maximum_location
        return result


class SequenceSummary:
    """仅保留整数标识作精确去重，不保存对应状态记录。"""

    def __init__(self):
        self.seen = set()
        self.repeats = 0
        self.previous = None
        self.backwards = 0

    def add(self, value):
        repeated = value in self.seen
        if repeated:
            self.repeats += 1
        self.seen.add(value)
        if self.previous is not None and value < self.previous:
            self.backwards += 1
        self.previous = value
        return not repeated

    def report(self):
        if not self.seen:
            return {"状态": "未取得", "唯一数量": 0, "重复次数": 0}
        first, last = min(self.seen), max(self.seen)
        return {"唯一数量": len(self.seen), "重复次数": self.repeats,
                "最小标识": first, "最大标识": last,
                "已观测首尾之间未出现的标识数量": last - first + 1 - len(self.seen),
                "相邻记录标识倒退次数": self.backwards}


def wall_time(value):
    """将已记录的 Unix 纳秒转换为明确标注 UTC 的时间。"""
    return datetime.fromtimestamp(value / 1_000_000_000, timezone.utc).isoformat()


def record_location(record, robot_timestamp=None):
    """保留日志行的稳定序号和机器人时间，不将主机时间冒充采样时间。"""
    return {"记录序号": record["seq"], "机器人timestamp_s": robot_timestamp}


def stop_summary(record, status):
    """提取停止及生命周期事件所需的小摘要，避免保存完整参数和状态。"""
    return {"记录序号": record["seq"], "类型": record["kind"],
            "记录墙钟_UTC": wall_time(record["wall_time_ns"]),
            "阶段": status["phase"], "退出码": status["exit_reason"],
            "退出原因": status["exit_reason_text"], "错误信息": status["last_error"]}


def analyze(run_dir):
    """流式读取已声明的第 1、2 版日志，只汇总本轮有效派生状态。"""
    run_dir = Path(run_dir).resolve()
    metadata_path = run_dir / "metadata.json"
    records_path = run_dir / "records.jsonl"
    with metadata_path.open(encoding="utf-8") as stream:
        metadata = json.load(stream)
    version = metadata["log_schema_version"]
    if version not in (1, 2):
        raise ValueError(f"{metadata_path} 的日志版本为 {version}；本工具只支持已声明的版本 1 和 2")
    context = metadata["context"]
    kinds = Counter()
    phases = Counter()
    valid_count = 0
    running_count = 0
    first_running = None
    last_running = None
    previous_running = None
    timestamp_intervals = NumericSummary()
    nonpositive_intervals = 0
    missing_running_timestamps = 0
    anchor = None
    anchor_change_count = 0
    drive_max = [NumericSummary() for _ in range(6)]
    command_offset_max = [NumericSummary() for _ in range(6)]
    actual_offset_max = [NumericSummary() for _ in range(6)]
    snapshot_sequences = SequenceSummary()
    sample_cycles = SequenceSummary()
    running_sample_cycles = SequenceSummary()
    diagnostic_axes = set()
    last_diagnostic = None
    diagnostic_ranges = {name: NumericSummary() for name in
                         ("tau_raw_nm", "bias_nm", "filtered_nm")}
    timing_fields = ("dt_model_actual_s", "servoj_start_interval_s", "servoj_duration_s",
                     "cycle_duration_s", "load_duration_s", "compute_duration_s", "publish_duration_s")
    diagnostic_timing = {name: NumericSummary() for name in timing_fields}
    operator_events = []
    logging_events = []
    stop_events = []
    gap_events = []
    gap_dropped_count = 0
    last_lifecycle = None

    with records_path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                record = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(f"{records_path}:{line_number} 不是完整有效的 JSON 记录：{error.msg}") from error
            if record["log_schema_version"] != version or record["run_id"] != metadata["run_id"]:
                raise ValueError(f"{records_path}:{line_number} 的版本或 run_id 与 metadata.json 不一致")
            kind = record["kind"]
            kinds[kind] += 1
            payload = record["payload"]

            if kind == "operator_event":
                operator_events.append({
                    "记录序号": record["seq"], "事件": payload["label"], "备注": payload["note"],
                    "事件墙钟_UTC": wall_time(payload["event_wall_time_ns"]),
                    "事件距日志开始_s": (payload["event_monotonic_ns"] - metadata["started_monotonic_ns"]) / 1_000_000_000,
                    "最近机器人状态": payload["latest_robot_state"], "关联说明": payload["association"],
                })
            elif kind == "logging_enabled":
                logging_events.append({
                    "记录序号": record["seq"], "开启": payload["enabled"],
                    "事件墙钟_UTC": wall_time(payload["wall_time_ns"]),
                    "累计停记跳过数量": payload["skipped_count"],
                })
            elif kind == "log_gap":
                gap_dropped_count += payload["dropped_count"]
                gap_events.append({"记录序号": record["seq"], "原因": payload["reason"],
                                   "丢弃数量": payload["dropped_count"],
                                   "首个丢弃序号": payload["first_seq"], "末个丢弃序号": payload["last_seq"],
                                   "记录类型": payload["kinds"]})
            elif kind in ("controller_phase", "controller_complete", "stop_requested",
                          "external_stop_confirmed", "controller_cancelled_before_start", "controller_error"):
                status = payload["status"]
                if kind != "controller_phase" or status["phase"] in (3, 4) or status["exit_reason"] != 0:
                    stop_events.append(stop_summary(record, status))
            elif kind == "controller_worker_failed":
                stop_events.append({
                    **stop_summary(record, payload["status"]),
                    "等待外部停止确认": payload["awaiting_external_stop_confirmation"],
                })

            if kind != "rtde_state":
                continue
            control = payload["control"]
            lifecycle_valid = payload["derived_valid"] if version == 1 else payload["lifecycle_valid"]
            if lifecycle_valid:
                last_lifecycle = stop_summary(record, control)
            if not payload["derived_valid"]:
                continue
            valid_count += 1
            phase = control["phase"]
            phases[phase] += 1
            current_anchor = control["q_start"]
            if current_anchor is not None:
                if anchor is None:
                    anchor = current_anchor
                elif current_anchor != anchor:
                    anchor_change_count += 1

            diagnostic = None if version == 1 else control["diagnostic"]
            if diagnostic is not None:
                diagnostic_axes.add(diagnostic["axis"])
                snapshot_sequences.add(diagnostic["snapshot_seq"])
                sample_cycles.add(diagnostic["sample_cycle"])
                # 停止入口才结算的异常周期也须保留，不能只查看 phase2 内的极值。
                last_diagnostic = {"记录序号": record["seq"], "phase": phase, **{
                    name: diagnostic[name] for name in (
                        "sample_cycle", "sample_time_s", "timing_cycle", "snapshot_seq",
                        "dt_base_s", "cycle_max_s", "cycle_overrun_count", "bias_sample_count",
                        "bias_std_nm", "cycle_duration_s",
                    )
                }}
            if phase != 2:
                continue
            running_count += 1
            robot = payload["raw"]
            timestamp = numeric_value(robot["timestamp"])
            location = record_location(record, timestamp)
            if timestamp is not None:
                current_running = (timestamp, control["cycle_count"])
                if first_running is None:
                    first_running = current_running
                last_running = current_running
                if previous_running is not None:
                    interval = timestamp - previous_running
                    timestamp_intervals.add(interval, location)
                    nonpositive_intervals += int(interval <= 0)
                previous_running = timestamp
            else:
                missing_running_timestamps += 1
                previous_running = None

            for axis in range(6):
                drive = numeric_value(control["drive"][axis])
                drive_max[axis].add(None if drive is None else abs(drive), location)
                command = numeric_value(control["q_cmd"][axis])
                actual = numeric_value(robot["actual_q"][axis])
                reference = None if anchor is None else numeric_value(anchor[axis])
                command_offset_max[axis].add(
                    None if command is None or reference is None else abs(command - reference), location)
                actual_offset_max[axis].add(
                    None if actual is None or reference is None else abs(actual - reference), location)

            if diagnostic is None or not running_sample_cycles.add(diagnostic["sample_cycle"]):
                continue
            diagnostic_location = {
                **location, "snapshot_seq": diagnostic["snapshot_seq"],
                "sample_cycle": diagnostic["sample_cycle"], "sample_time_s": diagnostic["sample_time_s"],
                "timing_cycle": diagnostic["timing_cycle"],
            }
            for name, summary in diagnostic_ranges.items():
                summary.add(diagnostic[name], diagnostic_location)
            for name, summary in diagnostic_timing.items():
                summary.add(diagnostic[name], diagnostic_location)

    span = None if first_running is None else last_running[0] - first_running[0]
    slope = None if span is None or span <= 0 else (last_running[1] - first_running[1]) / span
    diagnostic_report = {
        "状态": "未取得；版本 1 未声明内部诊断量" if version == 1 else "未取得有效诊断页",
        "说明": "不从电流、末端力或 drive 推造原始补偿力矩、偏置或内部周期。",
    }
    if snapshot_sequences.seen:
        diagnostic_report = {
            "状态": "已取得有效诊断页", "所选轴": sorted(diagnostic_axes),
            "全部有效诊断页snapshot_seq": snapshot_sequences.report(),
            "全部有效诊断页sample_cycle": sample_cycles.report(),
            "phase2诊断sample_cycle": running_sample_cycles.report(),
            "最后有效诊断快照_包含停止阶段": last_diagnostic,
            "最后快照说明": "覆盖全部有效阶段，包括 phase3 和 phase4；超周期可能到停止入口才结算，因此最后快照的 cycle_duration_s、cycle_max_s 和 cycle_overrun_count 应与 phase2 极值一起查看。",
            "序号解释": "只统计已观测最小与最大标识之间的缺口，不推断首帧前或末帧后丢失。缺口可能来自跨页写入导致无效页、控制器跳过输出、主机读取采样或日志缺口，不能直接归因为网络丢包。重复页不代表新的载荷样本。",
            "phase2唯一采样周期的载荷范围_Nm": {name: summary.report() for name, summary in diagnostic_ranges.items()},
            "phase2唯一采样页观测到的耗时最大值_s": {
                name: summary.report(maximum_only=True) for name, summary in diagnostic_timing.items()},
            "周期身份说明": "dt_model_actual_s、load_duration_s、compute_duration_s 属于 sample_cycle；servoj_start_interval_s、servoj_duration_s、cycle_duration_s、publish_duration_s 属于 timing_cycle。phase2 首页的 timing_cycle 可能仍指偏置末轮；最大值位置保留两种编号，不能视为同周期。",
        }
    return {
        "日志目录": str(run_dir), "日志版本": version, "run_id": metadata["run_id"],
        "场景": {"reference_source": context["reference_source"], "space": context["space"]},
        "记录数量": {"实际读取": sum(kinds.values()), "metadata记录数量": metadata["record_count"],
                     "按kind": dict(sorted(kinds.items()))},
        "RTDE": {"总数": kinds["rtde_state"], "derived_valid数量": valid_count,
                 "派生无效数量": kinds["rtde_state"] - valid_count,
                 "有效阶段数量": {str(key): value for key, value in sorted(phases.items())}},
        "phase2运行": {
            "有效RTDE数量": running_count,
            "首个机器人timestamp_s": None if first_running is None else first_running[0],
            "末个机器人timestamp_s": None if last_running is None else last_running[0],
            "机器人时间跨度_s": span,
            "相邻有效运行RTDE的timestamp间隔_s": timestamp_intervals.report(),
            "非正timestamp间隔数量": nonpositive_intervals,
            "未取得有限timestamp的运行记录数量": missing_running_timestamps,
            "首尾cycle_count斜率_周期每秒": slope,
            "周期斜率说明": "按首尾 cycle_count 差除以机器人时间跨度估计，不能视为每次 servoj 的实测频率；日志停记会使相邻已记录样本跨过缺口。",
        },
        "phase2载荷及锚点偏差": {
            "首个有效q_start_rad": anchor, "后续q_start与首个值不同的记录数": anchor_change_count,
            "drive单位": context["units_and_coordinates"]["drive"],
            "各轴drive最大绝对值": [item.report(maximum_only=True) for item in drive_max],
            "各关节q_cmd减锚点最大绝对值_rad": [item.report(maximum_only=True) for item in command_offset_max],
            "各关节actual_q减锚点最大绝对值_rad": [item.report(maximum_only=True) for item in actual_offset_max],
            "锚点说明": "使用有效派生状态中首次取得的 q_start；遥操作或未取得固定锚点时偏差为空，不将 q_nom 当作固定锚点。",
        },
        "诊断": diagnostic_report,
        "人工事件": operator_events,
        "人工事件说明": "空列表表示没有记录，不能推断没有施力或已松手。事件时间来自主机，最近机器人状态仅供异步关联。",
        "停止及生命周期事件": stop_events,
        "最后有效生命周期状态": last_lifecycle,
        "日志缺口及停记": {
            "log_gap事件数量": kinds["log_gap"], "log_gap声明丢弃数量之和": gap_dropped_count,
            "metadata丢弃数量": metadata["dropped_count"], "metadata停记跳过数量": metadata["skipped_count"],
            "缺口事件": gap_events, "日志开关事件": logging_events,
            "日志最初开启": context["debug_logging_enabled_at_start"],
            "metadata已结束": metadata["finished"], "session_finish数量": kinds["session_finish"],
        },
        "解释范围": "这是人工排查的描述性汇总，不作稳定性、安全性、回位或联调通过判定；缺失量明确保留为未取得。",
    }


def main():
    """从命令行读取一轮日志目录并输出中文 JSON 报告。"""
    parser = argparse.ArgumentParser(description="只读分析导纳日志；不连接设备、不修改日志、不自动判定通过或失败。")
    parser.add_argument("run_dir", type=Path, help="包含 metadata.json 和 records.jsonl 的单轮日志目录")
    args = parser.parse_args()
    print(json.dumps(analyze(args.run_dir), ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()

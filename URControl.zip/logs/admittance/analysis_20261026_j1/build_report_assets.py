"""只读分析三轮 J1 保持日志，生成报告统计和静态图，不连接设备。"""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import numpy as np


ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from analyze_admittance_log import analyze

OUT = Path(__file__).resolve().parent
RUNS = ["20261026_185950_405406_1", "20261026_190031_971558_2", "20261026_190053_703617_3"]
COLORS = ["#2878b5", "#d66b20", "#22956d", "#9a5eb3", "#b33f55", "#657383"]
plt.rcParams.update({
    "font.family": FontProperties(fname="/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc").get_name(),
    "axes.unicode_minus": False, "font.size": 10, "axes.grid": True,
    "grid.alpha": 0.2, "figure.facecolor": "white", "savefig.facecolor": "white",
})


def numbers(values):
    """按总体标准差汇总一个已明确包含有效样本的窗口。"""
    array = np.asarray(values, dtype=float)
    return {"mean": array.mean(axis=0).tolist(), "std": array.std(axis=0).tolist(),
            "min": array.min(axis=0).tolist(), "max": array.max(axis=0).tolist()}


def window(rows):
    """保存可由原始记录序号复核的窗口统计。"""
    diagnostic = [r["payload"]["control"]["diagnostic"] for r in rows]
    return {
        "count": len(rows), "first_seq": rows[0]["seq"], "last_seq": rows[-1]["seq"],
        "first_timestamp": rows[0]["payload"]["raw"]["timestamp"],
        "last_timestamp": rows[-1]["payload"]["raw"]["timestamp"],
        **{key: numbers([d[key] for d in diagnostic]) for key in ("tau_raw_nm", "bias_nm", "filtered_nm")},
        "drive": numbers([r["payload"]["control"]["drive"] for r in rows]),
        "actual_current": numbers([r["payload"]["raw"]["actual_current"] for r in rows]),
        "max_abs_actual_qd": np.abs([r["payload"]["raw"]["actual_qd"] for r in rows]).max(axis=0).tolist(),
        "actual_TCP_force": numbers([r["payload"]["raw"]["actual_TCP_force"] for r in rows]),
    }


datasets = []
stats = []
summaries = []
for run in RUNS:
    run_path = ROOT / "logs" / "admittance" / run
    rows = [json.loads(line) for line in (run_path / "records.jsonl").open(encoding="utf-8")]
    states = [r for r in rows if r["kind"] == "rtde_state" and r["payload"]["derived_valid"]]
    running = [r for r in states if r["payload"]["control"]["phase"] == 2]
    unique = {}
    for r in running:
        cycle = r["payload"]["control"]["diagnostic"]["sample_cycle"]
        if cycle > 751 and cycle not in unique:
            unique[cycle] = r
    samples = list(unique.values())
    t0 = running[0]["payload"]["raw"]["timestamp"]
    t_first = samples[0]["payload"]["raw"]["timestamp"]
    t_last = samples[-1]["payload"]["raw"]["timestamp"]
    events = [{"seq": r["seq"], "event": r["payload"]["event"], "label": r["payload"]["label"],
               "timestamp": r["payload"]["latest_robot_state"]["timestamp"]} for r in rows if r["kind"] == "operator_event"]
    windows = {
        "head_2s": [r for r in samples if r["payload"]["raw"]["timestamp"] <= t_first + 2 + 1e-7],
        "tail_3s": [r for r in samples if r["payload"]["raw"]["timestamp"] >= t_last - 3 - 1e-7],
        "tail_5s": [r for r in samples if r["payload"]["raw"]["timestamp"] >= t_last - 5 - 1e-7],
    }
    for event in events:
        if event["event"] == "released":
            windows["release_marker_plus_1s"] = [r for r in samples if r["payload"]["raw"]["timestamp"] >= event["timestamp"] + 1 - 1e-7]
    heartbeat = [r for r in rows if r["kind"] == "rtde_input" and r["payload"]["heartbeat_advanced"]]
    complete = [r for r in rows if r["kind"] == "controller_complete"][0]
    result = {"run": run, "phase2_first_timestamp": t0, "phase2_last_timestamp": t_last,
              "independent_samples": len(samples), "events": events,
              "windows": {name: window(items) for name, items in windows.items()},
              "heartbeat_success_interval_max_s": max(r["payload"]["timing"]["heartbeat_send_max_interval_s"] for r in heartbeat if r["payload"]["timing"]["heartbeat_send_max_interval_s"] is not None),
              "runtime_heartbeat_age_max_us": max(r["payload"]["control"]["heartbeat_age_us"] for r in running),
              "complete_seq": complete["seq"], "exit_reason": complete["payload"]["status"]["exit_reason"],
              "stopped_confirmed": complete["payload"]["status"]["stopped_confirmed"]}
    stats.append(result)
    datasets.append({"samples": samples, "states": states, "events": events, "t0": t0, "t_last": t_last, "heartbeat": heartbeat})
    summaries.append(analyze(run_path))

confirmed = {"第1轮": "全程无接触", "第2、3轮": "在完全松手附近点击按钮，时刻仍为近似标记",
             "三轮共同条件": "无嗡鸣，未移动机器人，未更改工具和负载"}
(OUT / "statistics.json").write_text(json.dumps({"用户确认": confirmed, "统计口径": "载荷按sample_cycle去重，剔除cycle751；头2秒起于首个实际运行样本；尾窗包含端点；电流及TCP力仅取这些页关联的RTDE值，不视为与脚本载荷同步采样", "runs": stats}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(OUT / "summaries.json").write_text(json.dumps(summaries, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

fig, axes = plt.subplots(3, 2, figsize=(15, 10), constrained_layout=True)
for index, dataset in enumerate(datasets):
    samples = dataset["samples"]
    t = np.array([r["payload"]["raw"]["timestamp"] for r in samples]) - dataset["t0"]
    d = [r["payload"]["control"]["diagnostic"] for r in samples]
    drive = np.array([r["payload"]["control"]["drive"] for r in samples])
    left, right = axes[index]
    left.plot(t, [x["tau_raw_nm"] - x["bias_nm"] for x in d], color="#b0b8c4", lw=0.7, label="J1 raw − bias")
    left.plot(t, [x["filtered_nm"] for x in d], color=COLORS[0], lw=1.4, label="J1 filtered（死区前）")
    left.plot(t, drive[:, 0], color=COLORS[3], lw=1.2, label="J1 drive（死区后）")
    for threshold in (-3, 3):
        left.axhline(threshold, color="#687787", linestyle="--", lw=0.9)
    for axis in range(6):
        right.plot(t, drive[:, axis], color=COLORS[axis], lw=1.2, label=f"J{axis+1}")
    ending = "15秒定时结束" if index != 1 else "14.048秒心跳超时"
    left.set_title(f"第{index+1}轮 · J1载荷 · {ending}", loc="left", fontweight="bold")
    right.set_title(f"第{index+1}轮 · 六轴有效驱动力", loc="left", fontweight="bold")
    for ax in (left, right):
        ax.set_xlim(0, 15.05)
        ax.set_ylabel("力矩（N·m）")
        ax.set_xlabel("距首个phase 2状态的机器人时间（s）")
        ax.axvspan(t[-1] - 3, t[-1], color="#d6e9dc", alpha=0.35)
        for event in dataset["events"]:
            color = "#d66b20" if event["event"] == "force_start" else "#22956d"
            ax.axvline(event["timestamp"] - dataset["t0"], color=color, linestyle=":", lw=1.4)
            ax.text(event["timestamp"] - dataset["t0"] + 0.07, 0.96, event["label"] + "≈", transform=ax.get_xaxis_transform(), color=color, va="top", fontsize=9)
        ax.legend(loc="lower left", ncol=3, fontsize=8)
fig.suptitle("三轮J1固定保持：载荷与驱动力\n绿色浅底为各轮末3秒；事件虚线仅表示按钮关联时刻；六轴命令始终固定", fontsize=16, fontweight="bold")
fig.savefig(OUT / "j1_load_overview.png", dpi=160)
plt.close(fig)

fig, axes = plt.subplots(1, 3, figsize=(16, 4.6), constrained_layout=True)
for index, dataset in enumerate(datasets):
    rows = dataset["samples"]
    tail = [r for r in rows if r["payload"]["raw"]["timestamp"] >= dataset["t_last"] - 3 - 1e-7]
    t = np.array([r["payload"]["raw"]["timestamp"] for r in tail]) - dataset["t_last"]
    axes[0].plot(t, [r["payload"]["control"]["diagnostic"]["filtered_nm"] for r in tail], color=COLORS[index], lw=1, label=f"第{index+1}轮")
    axes[1].plot(t, [r["payload"]["control"]["drive"][2] for r in tail], color=COLORS[index], lw=1, label=f"第{index+1}轮")
for threshold in (-3, 3):
    axes[0].axhline(threshold, color="#687787", linestyle="--", lw=1)
axes[0].set_title("J1末3秒：drive=0仍可能有基线偏移", fontweight="bold")
axes[1].set_title("J3末3秒：第3轮持续正向drive", fontweight="bold")
for ax in axes[:2]:
    ax.set_xlabel("距本轮最后运行样本（s）")
    ax.set_ylabel("力矩（N·m）")
    ax.legend(loc="lower left", ncol=3, fontsize=9)
    ax.set_xlim(-3, 0)
x = np.arange(3)
for offset, key, color, label in [(-0.25, "bias", "#657383", "本轮固定bias"), (0, "head_2s", COLORS[0], "头2秒raw均值"), (0.25, "tail_3s", COLORS[1], "尾3秒raw均值")]:
    vals = [s["windows"]["head_2s"]["bias_nm"]["mean"] if key == "bias" else s["windows"][key]["tau_raw_nm"]["mean"] for s in stats]
    axes[2].bar(x + offset, vals, width=0.24, label=label, color=color)
axes[2].set_xticks(x, ["第1轮", "第2轮", "第3轮"])
axes[2].set_title("J1绝对基线：姿态近似相同", fontweight="bold")
axes[2].set_ylabel("力矩（N·m）")
axes[2].legend(loc="upper left", fontsize=8)
fig.suptitle("尾段放大与跨轮偏置对照｜第2轮尾窗含松手标记前约0.46秒，报告另核对标记后1秒窗口", fontsize=13)
fig.savefig(OUT / "j1_residual_detail.png", dpi=160)
plt.close(fig)

fig, axes = plt.subplots(2, 1, figsize=(11, 7), constrained_layout=True)
dataset = datasets[1]
first_stop = [r for r in dataset["states"] if r["payload"]["control"]["phase"] == 3][0]
tail_states = [r for r in dataset["states"] if dataset["t_last"] - 0.25 <= r["payload"]["raw"]["timestamp"] <= first_stop["payload"]["raw"]["timestamp"]]
axes[0].plot([r["payload"]["raw"]["timestamp"] for r in tail_states], [r["payload"]["control"]["heartbeat_age_us"] / 1000 for r in tail_states], color=COLORS[0], marker=".", markersize=3)
axes[0].axvline(first_stop["payload"]["raw"]["timestamp"], color=COLORS[1], linestyle=":", label="首次phase 3／退出码2")
axes[0].axhline(80, color="#b33f55", linestyle="--", label="80 ms超时阈值")
axes[0].set_title("机器人时间：心跳回显年龄超过阈值，进入停止", loc="left", fontweight="bold")
axes[0].set_xlabel("机器人timestamp（s）")
axes[0].set_ylabel("心跳年龄（ms）")
axes[0].legend(loc="upper left")
hb = [r for r in dataset["heartbeat"] if 284412.25 <= r["payload"]["host_monotonic_s"] <= 284412.65]
axes[1].plot([r["payload"]["host_monotonic_s"] for r in hb], [r["payload"]["timing"]["heartbeat_send_interval_s"] * 1000 for r in hb], marker="o", color=COLORS[1], label="成功发送间隔")
axes[1].plot([r["payload"]["host_monotonic_s"] for r in hb], [r["payload"]["send_duration_s"] * 1000 for r in hb], marker=".", color=COLORS[3], label="发送调用墙钟耗时")
axes[1].axhline(20, color="#657383", linestyle="--", label="计划周期20 ms")
axes[1].set_title("主机时间：最大成功发送间隔90.297 ms，发送调用耗时46.134 ms", loc="left", fontweight="bold")
axes[1].set_xlabel("主机单调时钟（s）")
axes[1].set_ylabel("间隔／耗时（ms）")
axes[1].legend(loc="upper left")
for ax in axes:
    ax.ticklabel_format(axis="x", style="plain", useOffset=False)
fig.suptitle("第2轮心跳超时证据｜上下图时钟独立，不能按横向位置对齐事件", fontsize=14, fontweight="bold")
fig.savefig(OUT / "heartbeat_timeout.png", dpi=160)
plt.close(fig)
for result in stats:
    print(result["run"], "独立载荷样本", result["independent_samples"])
    for name, values in result["windows"].items():
        print(name, "样本", values["count"], "filtered均值", round(values["filtered_nm"]["mean"], 6), "J3 drive均值", round(values["drive"]["mean"][2], 6))

"""导纳 RTDE 状态配方、帧长度及日志字段说明。"""


# 字段顺序同时用于机器人配方与日志；向量在采集时复制为独立列表。
ROBOT_FIELDS = (
    ("timestamp", "DOUBLE", "s", "机器人控制器运行时间"),
    ("runtime_state", "UINT32", None, "机器人程序运行状态"),
    ("actual_q", "VECTOR6D", "rad", "实际关节角"),
    ("actual_qd", "VECTOR6D", "rad/s", "实际关节角速度"),
    ("actual_TCP_pose", "VECTOR6D", ["m"] * 3 + ["rad"] * 3, "基座坐标下的实际 TCP 位姿"),
    ("safety_status_bits", "UINT32", None, "安全状态位"),
    ("robot_mode", "INT32", None, "机器人模式"),
    ("safety_mode", "INT32", None, "安全模式"),
    ("robot_status_bits", "UINT32", None, "机器人状态位"),
    ("speed_scaling", "DOUBLE", "比例", "轨迹限速比例"),
    ("target_speed_fraction", "DOUBLE", "比例", "目标速度比例"),
    ("actual_TCP_speed", "VECTOR6D", ["m/s"] * 3 + ["rad/s"] * 3, "实际 TCP 速度"),
    ("actual_TCP_force", "VECTOR6D", ["N"] * 3 + ["N*m"] * 3, "RTDE 实际 TCP 力和力矩；不是补偿关节力矩，也不是导纳处理后的 drive"),
    ("actual_current", "VECTOR6D", "A", "实际关节电流；不等同于补偿关节力矩"),
    ("joint_temperatures", "VECTOR6D", "摄氏度", "关节温度"),
    ("target_q", "VECTOR6D", "rad", "控制器轨迹目标关节角；不等同于脚本 q_cmd"),
    ("target_qd", "VECTOR6D", "rad/s", "控制器轨迹目标关节角速度"),
    ("actual_execution_time", "DOUBLE", "ms", "控制器实时线程执行耗时"),
    ("tcp_offset", "VECTOR6D", ["m"] * 3 + ["rad"] * 3, "TCP 相对法兰的配置偏移"),
    ("payload", "DOUBLE", "kg", "当前负载质量"),
    ("payload_cog", "VECTOR3D", "m", "当前负载质心"),
    ("payload_inertia", "VECTOR6D", "kg*m^2", "当前负载惯性张量"),
)

_TYPE_BYTES = {"DOUBLE": 8, "UINT32": 4, "INT32": 4, "VECTOR6D": 48, "VECTOR3D": 24}
_INT_FIELDS = ("phase", "exit_reason", "adopted_source_seq", "cycle_count", "reference_source",
               "heartbeat_echo", "heartbeat_age_us", "heartbeat_max_interval_us")
_DIAGNOSTIC_INT_FIELDS = (
    "snapshot_seq_begin", "snapshot_seq_end", "layout", "axis", "sample_time_us",
    "servoj_duration_us", "cycle_duration_us", "cycle_max_us", "load_duration_us",
    "compute_duration_us", "publish_duration_us", "bias_sample_count", "bias_std_micro_nm",
    "cycle_overrun_count", "dt_base_us", "timing_cycle",
)
_DIAGNOSTIC_FLOAT_FIELDS = (
    ("tau_raw_nm", "N*m"), ("bias_nm", "N*m"), ("filtered_nm", "N*m"),
    ("v_delta_rad_s", "rad/s"), ("dt_model_actual_s", "s"), ("servoj_start_interval_s", "s"),
)


def output_int_count(config: dict) -> int:
    """诊断占用输出整数上半区完整 24 项；普通导纳仍只占 8 项。"""
    return 24 if config["DIAGNOSTIC_AXIS"] else 8


def state_frequency(config: dict) -> float:
    """本轮显式诊断使用专属频率，普通导纳沿用原状态频率。"""
    return config["DIAGNOSTIC_STATE_HZ"] if config["DIAGNOSTIC_AXIS"] else config["ADMITTANCE_STATE_HZ"]


def output_recipe(config: dict) -> tuple[list[str], list[str]]:
    """返回标准机器人字段及本项目占用的完整输出寄存器配方。"""
    names = [field[0] for field in ROBOT_FIELDS]
    types = [field[1] for field in ROBOT_FIELDS]
    int_count = output_int_count(config)
    names += [f"output_int_register_{config['ADMITTANCE_OUTPUT_INT_BASE'] + index}" for index in range(int_count)]
    types += ["INT32"] * int_count
    names += [f"output_double_register_{config['ADMITTANCE_OUTPUT_FLOAT_BASE'] + index}" for index in range(24)]
    types += ["DOUBLE"] * 24
    return names, types


def output_packet_size(config: dict) -> int:
    """计算完整 RTDE 数据包字节数，包含三字节头和一字节配方编号。"""
    _, types = output_recipe(config)
    return 4 + sum(_TYPE_BYTES[field_type] for field_type in types)


def robot_sample(state) -> dict:
    """提取独立机器人状态，不保留 RTDE 接收对象及其中的向量引用。"""
    result = {}
    for name, field_type, _, _ in ROBOT_FIELDS:
        value = getattr(state, name)
        if field_type.startswith("VECTOR"):
            result[name] = list(value)
        elif field_type in ("INT32", "UINT32"):
            result[name] = int(value)
        else:
            result[name] = float(value)
    return result


def log_schema(config: dict, space: str) -> dict:
    """给每轮日志写入配方和实际可观测量的含义。"""
    int_base = config["ADMITTANCE_OUTPUT_INT_BASE"]
    float_base = config["ADMITTANCE_OUTPUT_FLOAT_BASE"]
    diagnostic = bool(config["DIAGNOSTIC_AXIS"])
    int_fields = _INT_FIELDS + _DIAGNOSTIC_INT_FIELDS if diagnostic else _INT_FIELDS
    registers = {f"output_int_register_{int_base + index}": name
                 for index, name in enumerate(int_fields)}
    for offset, name in ((0, "drive"), (6, "delta_q" if space == "joint" else "delta_x"),
                         (12, "q_cmd"), (18, "q_nom")):
        for axis in range(6):
            registers[f"output_double_register_{float_base + offset + axis}"] = f"{name}[{axis}]"
    if diagnostic:
        for index, (name, unit) in enumerate(_DIAGNOSTIC_FLOAT_FIELDS):
            registers[f"output_double_register_{float_base + 18 + index}"] = {
                "layout_1": {"field": f"q_anchor[{index}]", "unit": "rad"},
                "layout_2": {"field": f"diagnostic.{name}", "unit": unit},
            }
    schema = {
        "telemetry_schema_version": 2 if diagnostic else 1,
        "layout": "fixed_joint_hold_diagnostic" if diagnostic else "normal_admittance",
        "robot_fields": {name: {"rtde_type": field_type, "unit": unit, "description": description}
                         for name, field_type, unit, description in ROBOT_FIELDS},
        "output_registers": registers,
        "output_packet_bytes": output_packet_size(config),
        "host_monotonic_s": "主机单调时间，用于对齐接收、发送和控制诊断",
        "host_time_unix_s": "主机 Unix 时间，用于与外部日志对齐",
        "drive": "脚本经过静止偏置扣除、滤波、目标载荷扣除和连续死区后的有效驱动载荷",
        "unreported_values": "脚本未上报的补偿关节力矩原始样本、偏置、滤波中间量和导纳内部速度未记录为测量值",
        "program_seen": "已看到属于本轮脚本的初始化或启动取消停止页；为假时输出寄存器可能来自此前程序",
        "lifecycle_valid": "当前 RTDE 页已识别为本轮且整数页一致；停止页不依赖锚点确认即可更新阶段和退出原因",
        "derived_valid": "当前 RTDE 页可解码脚本样本；诊断还要求已确认本轮锚点，不代表 RTDE 原始机器人字段与脚本载荷同时采样",
    }
    if diagnostic:
        schema.update(
            drive="固定关节保持诊断仍计算扣偏置、滤波及死区后的载荷，但不据此更新目标或积分模型",
            unreported_values="原始补偿关节力矩、偏置、滤波和模型速度仅上报所选轴；未上报轴不能补零作为测量值",
            diagnostic={
                "enabled": "本轮是否为固定关节保持诊断",
                "axis": "启动前指定的关节，编号 1 至 6",
                "duration_s": "配置的诊断运行时长，秒；不包含稳定保持及偏置采样阶段",
                "layout": "1 为锚点页，2 为所选轴诊断页",
                "snapshot_seq": "同一发布页起止序号相等且大于零才可解码；重复页不是新采样",
                "sample_cycle": "本页 cycle_count；载荷、计算耗时对应此周期",
                "sample_time_s": "从脚本计时原点起的秒数；锚点页为循环起点，诊断页为载荷读取起点，不能当作 RTDE timestamp",
                "anchor_confirmed": "主机已从本轮一致锚点页保存六轴锚点，并允许发送 anchor_ack=1",
                "tau_raw_nm": "所选轴 get_joint_torques 原始补偿关节力矩，牛米；锚点页为空",
                "bias_nm": "本轮已确认并固定的所选轴静止偏置，牛米；锚点页为空",
                "filtered_nm": "所选轴扣偏置后滤波载荷，牛米；锚点页为空",
                "v_delta_rad_s": "所选轴模型内部速度，弧度每秒；保持诊断不积分模型，锚点页为空",
                "dt_model_actual_s": "当前载荷读取起点距前次运行载荷读取起点的秒数；保持诊断不积分模型；首次未获得为空",
                "servoj_start_interval_s": "上一完成伺服周期与其前次伺服开始的间隔，秒，属于 timing_cycle；首次未获得为空",
                "dt_base_s": "get_steptime 基础控制步长，秒，不是实测整轮间隔",
                "timing_cycle": "servoj_duration_s、cycle_duration_s、publish_duration_s、servoj_start_interval_s 对应的上一完成周期编号；尚未完成为空",
                "servoj_duration_s": "timing_cycle 对应 servoj 调用耗时，秒",
                "cycle_duration_s": "timing_cycle 对应整轮耗时，包含发布及伺服调用，秒",
                "cycle_max_s": "本轮已完成周期耗时的最大值，秒",
                "load_duration_s": "sample_cycle 对应载荷读取耗时，秒",
                "compute_duration_s": "sample_cycle 对应输入及约束计算耗时，不含载荷、发布和伺服，秒",
                "publish_duration_s": "timing_cycle 对应寄存器发布耗时，秒",
                "bias_sample_count": "截至本页的静止偏置采样数量",
                "bias_std_nm": "完成偏置后所选轴总体标准差，牛米；未完成为空；线上缩放为微牛米整数",
                "cycle_overrun_count": "已完成整轮耗时超过 dt_base 的次数，不等同于日志或 RTDE 丢包",
            },
            diagnostic_input={
                f"input_int_register_{config['ADMITTANCE_INPUT_INT_BASE'] + 5}":
                    "anchor_ack：本轮初始为 0；保存本轮一致锚点页后为 1；不自动重捕锚点或重启",
            },
            diagnostic_decoding="整数序号不一致、轴或布局不匹配、未识别本轮，或诊断页到达时本轮锚点尚未确认：原始字段仍写日志，derived_valid=false；当前脚本样本及 diagnostic 清空为 None，禁止与新机器人字段混合；本轮一致停止页仍更新生命周期和退出原因",
            diagnostic_time_encoding="以 _us 结尾的整数单位为微秒；_s 派生字段统一换算为秒；间隔、标准差和前周期计时未获得时，脚本 -1 解码为 None",
            q_nom="有效页的固定 q_nom 始终来自本轮已确认的锚点缓存；无效页清空 q_nom；q_start 是本轮不变锚点上下文，确认后保留；布局 2 最后六浮点不得作为位置",
        )
    return schema
